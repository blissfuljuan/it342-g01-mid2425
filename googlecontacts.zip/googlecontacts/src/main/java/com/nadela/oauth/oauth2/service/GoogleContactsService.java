package com.nadela.oauth.oauth2.service;

import com.nadela.oauth.oauth2.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.security.Principal;
import java.util.List;
import java.util.Map;

@Service
public class GoogleContactsService {

    @Autowired
    private OAuth2AuthorizedClientService authorizedClientService;

    // Get authenticated user info
    public Map<String, String> getAuthenticatedUserInfo(Principal principal) {
        OAuth2User oAuth2User = (OAuth2User) ((Authentication) principal).getPrincipal();
        return Map.of(
                "name", oAuth2User.getAttribute("name"),
                "email", oAuth2User.getAttribute("email")
        );
    }

    // Get contacts from Google People API
    public List<Person> getContacts(Principal principal) {
        OAuth2AuthorizedClient client = authorizedClientService.loadAuthorizedClient(
                "google",
                principal.getName()
        );

        String accessToken = client.getAccessToken().getTokenValue();

        // Use RestTemplate to call Google People API
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(accessToken);

        HttpEntity<String> entity = new HttpEntity<>(headers);

        ResponseEntity<Map> response = new RestTemplate().exchange(
                "https://people.googleapis.com/v1/people/me/connections?personFields=names,emailAddresses,phoneNumbers",
                HttpMethod.GET,
                entity,
                Map.class
        );

        return (List<Person>) response.getBody().get("connections");
    }

    // Create a new contact
    public Person createContact(Person newContact, Principal principal) {
        OAuth2AuthorizedClient client = authorizedClientService.loadAuthorizedClient(
                "google",
                principal.getName()
        );

        String accessToken = client.getAccessToken().getTokenValue();

        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(accessToken);
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Person> entity = new HttpEntity<>(newContact, headers);

        ResponseEntity<Person> response = new RestTemplate().exchange(
                "https://people.googleapis.com/v1/people:createContact",
                HttpMethod.POST,
                entity,
                Person.class
        );

        return response.getBody();
    }

    // Update an existing contact
    public Person updateContact(String resourceName, Person updatedContact, Principal principal) {
        OAuth2AuthorizedClient client = authorizedClientService.loadAuthorizedClient(
                "google",
                principal.getName()
        );

        String accessToken = client.getAccessToken().getTokenValue();

        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(accessToken);
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Person> entity = new HttpEntity<>(updatedContact, headers);

        ResponseEntity<Person> response = new RestTemplate().exchange(
                "https://people.googleapis.com/v1/" + resourceName + ":updateContact",
                HttpMethod.PUT,
                entity,
                Person.class
        );

        return response.getBody();
    }

    // Delete a contact
    public void deleteContact(String resourceName, Principal principal) {
        OAuth2AuthorizedClient client = authorizedClientService.loadAuthorizedClient(
                "google",
                principal.getName()
        );

        String accessToken = client.getAccessToken().getTokenValue();

        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(accessToken);

        HttpEntity<String> entity = new HttpEntity<>(headers);

        new RestTemplate().exchange(
                "https://people.googleapis.com/v1/" + resourceName + ":deleteContact",
                HttpMethod.DELETE,
                entity,
                Void.class
        );
    }
}

