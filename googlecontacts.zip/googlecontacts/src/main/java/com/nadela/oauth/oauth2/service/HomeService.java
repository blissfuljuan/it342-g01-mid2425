package com.nadela.oauth.oauth2.service;

public class HomeService {
}
