package com.nadela.oauth.oauth2.controller;

import com.nadela.oauth.oauth2.Person;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.annotation.RegisteredOAuth2AuthorizedClient;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
public class ContactController {

    @Value("${spring.security.oauth2.client.registration.google.client-id}")
    private String clientId;

    @Value("${spring.security.oauth2.client.registration.google.client-secret}")
    private String clientSecret;

    // Google People API endpoint for connections (contacts)
    private static final String GOOGLE_PEOPLE_API = "https://people.googleapis.com/v1/people/me/connections?personFields=names,emailAddresses,photos";

    @GetMapping("/contact")
    public String contact(Model model,
                          @AuthenticationPrincipal OAuth2User oauth2User,
                          @RegisteredOAuth2AuthorizedClient("google") OAuth2AuthorizedClient authorizedClient) {

        // Access token to call Google People API
        String accessToken = authorizedClient.getAccessToken().getTokenValue();

        System.out.println("Token: " + accessToken);
        // Prepare HTTP headers with Bearer token
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(accessToken);
        //headers.setBearerAuth("Bearer " + accessToken);
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));

        HttpEntity<String> entity = new HttpEntity<>(headers);

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Map> response = restTemplate.exchange(GOOGLE_PEOPLE_API, HttpMethod.GET, entity, Map.class);

        if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
            Map body = response.getBody();
            // The contacts are under "connections" key
            List<Map<String, Object>> connections = (List<Map<String, Object>>) body.get("connections");
            model.addAttribute("connections", connections);
        } else {
            model.addAttribute("connections", List.of());
        }

        // Pass user info to template
        model.addAttribute("userName", oauth2User.getAttribute("name"));
        model.addAttribute("userEmail", oauth2User.getAttribute("email"));

        return "contacts";
    }

    @GetMapping("/addContact")
    public String addContact() {

        return "addContact";
    }

    @GetMapping("/editContact")
    public String editContact() {

        return "editContact";
    }
}

