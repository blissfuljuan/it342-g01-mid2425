package com.nadela.oauth.oauth2.controller;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping("/contact")
public class ContactController {

    // In-memory contact store for demo (id to contact map)
    private final Map<Long, Contact> contacts = Collections.synchronizedMap(new LinkedHashMap<>());
    private final AtomicLong idGenerator = new AtomicLong(1);

    // Contact data class
    static class Contact {
        Long id;
        String name;
        String email;
        String phone;

        Contact(Long id, String name, String email, String phone) {
            this.id = id;
            this.name = name;
            this.email = email;
            this.phone = phone;
        }
    }

    // Initialize some mock contacts for demo
    public ContactController() {
        contacts.put(idGenerator.get(), new Contact(idGenerator.getAndIncrement(), "Alice Johnson", "alice@example.com", "+1234567890"));
        contacts.put(idGenerator.get(), new Contact(idGenerator.getAndIncrement(), "Bob Smith", "bob.smith@example.com", "+1987654321"));
        contacts.put(idGenerator.get(), new Contact(idGenerator.getAndIncrement(), "Carol Lee", "carol.lee@example.com", "+1122334455"));
    }

    // Helper method to generate HTML header with material icons and styles
    private String htmlHeader(String title) {
        return "<!DOCTYPE html>\n" +
                "<html lang=\"en\">\n" +
                "<head>\n" +
                "  <meta charset=\"UTF-8\" />\n" +
                "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />\n" +
                "  <title>" + title + "</title>\n" +
                "  <link href=\"https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap\" rel=\"stylesheet\" />\n" +
                "  <link href=\"https://fonts.googleapis.com/icon?family=Material+Icons\" rel=\"stylesheet\" />\n" +
                "  <style>\n" +
                "    body { font-family: 'Poppins', sans-serif; margin: 0; background: #ffffff; color: #374151; }\n" +
                "    .container { max-width: 1200px; margin: auto; padding: 40px 20px; }\n" +
                "    h1 { font-weight: 600; font-size: 48px; margin-bottom: 24px; color: #1f2937; }\n" +
                "    p { color: #6b7280; font-size: 18px; margin-bottom: 32px; }\n" +
                "    a.button-primary {\n" +
                "      background: #6366f1;\n" +
                "      color: white;\n" +
                "      padding: 12px 24px;\n" +
                "      border-radius: 12px;\n" +
                "      text-decoration: none;\n" +
                "      font-weight: 600;\n" +
                "      display: inline-flex;\n" +
                "      align-items: center;\n" +
                "      gap: 8px;\n" +
                "      transition: background-color 0.3s ease;\n" +
                "    }\n" +
                "    a.button-primary:hover { background: #4f46e5; }\n" +
                "    .contact-card {\n" +
                "      background: #f9fafb;\n" +
                "      border-radius: 12px;\n" +
                "      box-shadow: 0 4px 6px rgba(0,0,0,0.05);\n" +
                "      padding: 20px;\n" +
                "      margin-bottom: 16px;\n" +
                "      display: flex;\n" +
                "      align-items: center;\n" +
                "      gap: 16px;\n" +
                "    }\n" +
                "    .avatar {\n" +
                "      width: 60px;\n" +
                "      height: 60px;\n" +
                "      border-radius: 50%;\n" +
                "      background-color: #8b5cf6;\n" +
                "      color: white;\n" +
                "      font-weight: 700;\n" +
                "      font-size: 24px;\n" +
                "      display: flex;\n" +
                "      align-items: center;\n" +
                "      justify-content: center;\n" +
                "      user-select: none;\n" +
                "      flex-shrink: 0;\n" +
                "    }\n" +
                "    .contact-info {\n" +
                "      flex-grow: 1;\n" +
                "    }\n" +
                "    .contact-name {\n" +
                "      font-size: 20px;\n" +
                "      font-weight: 600;\n" +
                "      color: #111827;\n" +
                "    }\n" +
                "    .contact-details {\n" +
                "      font-size: 16px;\n" +
                "      color: #4b5563;\n" +
                "      margin-top: 4px;\n" +
                "    }\n" +
                "    .icon-button {\n" +
                "      background: transparent;\n" +
                "      border: none;\n" +
                "      color: #6366f1;\n" +
                "      cursor: pointer;\n" +
                "      font-size: 24px;\n" +
                "      padding: 4px;\n" +
                "      transition: color 0.2s;\n" +
                "    }\n" +
                "    .icon-button:hover {\n" +
                "      color: #4f46e5;\n" +
                "    }\n" +
                "    form {\n" +
                "      max-width: 500px;\n" +
                "      background: #f9fafb;\n" +
                "      padding: 24px;\n" +
                "      border-radius: 12px;\n" +
                "      box-shadow: 0 4px 6px rgba(0,0,0,0.05);\n" +
                "    }\n" +
                "    label {\n" +
                "      display: block;\n" +
                "      font-weight: 600;\n" +
                "      margin-bottom: 6px;\n" +
                "      color: #374151;\n" +
                "    }\n" +
                "    input[type=text], input[type=email], input[type=tel] {\n" +
                "      width: 100%;\n" +
                "      padding: 10px 12px;\n" +
                "      border-radius: 8px;\n" +
                "      border: 1.5px solid #d1d5db;\n" +
                "      margin-bottom: 20px;\n" +
                "      font-size: 16px;\n" +
                "      color: #1f2937;\n" +
                "      transition: border-color 0.3s ease;\n" +
                "    }\n" +
                "    input[type=text]:focus, input[type=email]:focus, input[type=tel]:focus {\n" +
                "      border-color: #6366f1;\n" +
                "      outline: none;\n" +
                "    }\n" +
                "    button.submit-btn {\n" +
                "      background: #6366f1;\n" +
                "      color: white;\n" +
                "      font-weight: 600;\n" +
                "      border: none;\n" +
                "      padding: 14px 28px;\n" +
                "      border-radius: 12px;\n" +
                "      cursor: pointer;\n" +
                "      font-size: 18px;\n" +
                "      transition: background-color 0.3s ease;\n" +
                "      display: inline-flex;\n" +
                "      align-items: center;\n" +
                "      gap: 8px;\n" +
                "    }\n" +
                "    button.submit-btn:hover {\n" +
                "      background: #4f46e5;\n" +
                "    }\n" +
                "    a.back-link {\n" +
                "      display: inline-block;\n" +
                "      margin-top: 20px;\n" +
                "      color: #6b7280;\n" +
                "      text-decoration: underline;\n" +
                "      font-weight: 600;\n" +
                "      cursor: pointer;\n" +
                "    }\n" +
                "    a.back-link:hover {\n" +
                "      color: #374151;\n" +
                "    }\n" +
                "    @media (max-width: 640px) {\n" +
                "      .container { padding: 20px; }\n" +
                "      h1 { font-size: 36px; }\n" +
                "      .contact-card { flex-direction: column; align-items: flex-start; }\n" +
                "      .avatar { width: 50px; height: 50px; font-size: 20px; }\n" +
                "    }\n" +
                "  </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "<div class=\"container\">\n";
    }

    private String htmlFooter() {
        return "</div>\n</body>\n</html>";
    }

    // Utility to get initials from name
    private String getInitials(String name) {
        if (name == null || name.isEmpty()) return "";
        String[] parts = name.trim().split(\" \");
                String initials = \"\";
        for (int i = 0; i < Math.min(parts.length, 2); i++) {
            initials += parts[i].substring(0, 1).toUpperCase();
        }
        return initials;
    }

    // Display contacts page listing all contacts
    @GetMapping("")
    public String contacts(@AuthenticationPrincipal OAuth2User principal) {
        StringBuilder html = new StringBuilder();
        html.append(htmlHeader("Contacts"));

        html.append("<h1>Your Google Contacts</h1>");
        html.append("<p>View and manage your Google contacts.</p>");
        html.append("<a href=\"/contact/add\" class=\"button-primary\"><span class=\"material-icons\">person_add</span>Add Contact</a>");
        html.append("<div style=\"margin-top: 32px;\">");

        if (contacts.isEmpty()) {
            html.append("<p>No contacts found.</p>");
        } else {
            for (Contact c : contacts.values()) {
                html.append("<div class=\"contact-card\">");
                html.append("<div class=\"avatar\" aria-label=\"Contact initials\">" + getInitials(c.name) + "</div>");
                html.append("<div class=\"contact-info\">");
                html.append("<div class=\"contact-name\">" + c.name + "</div>");
                html.append("<div class=\"contact-details\">");
                html.append("Email: " + c.email + "<br/>");
                html.append("Phone: " + c.phone);
                html.append("</div></div>");
                html.append("<div>");
                html.append("<a href=\"/contact/edit?id=" + c.id + "\" class=\"icon-button\" aria-label=\"Edit contact " + c.name + "\"><span class=\"material-icons\">edit</span></a>");
                html.append("</div>");
                html.append("</div>");
            }
        }

        html.append("</div>");
        html.append(htmlFooter());
        return html.toString();
    }

    // Display add contact form
    @GetMapping("/add")
    public String addContact() {
        StringBuilder html = new StringBuilder();
        html.append(htmlHeader("Add Contact"));
        html.append("<h1>Add New Contact</h1>");
        html.append("<form method=\"post\" action=\"/contact/add\">");
        html.append("<label for=\"name\">Full Name</label>");
        html.append("<input type=\"text\" id=\"name\" name=\"name\" required />");

        html.append("<label for=\"email\">Email</label>");
        html.append("<input type=\"email\" id=\"email\" name=\"email\" required />");

        html.append("<label for=\"phone\">Phone</label>");
        html.append("<input type=\"tel\" id=\"phone\" name=\"phone\" />");

        html.append("<button type=\"submit\" class=\"submit-btn\"><span class=\"material-icons\">person_add</span>Add Contact</button>");
        html.append("</form>");
        html.append("<a href=\"/contact\" class=\"back-link\">&larr; Back to Contacts</a>");
        html.append(htmlFooter());
        return html.toString();
    }

    // Handle add contact form submission
    @PostMapping("/add")
    public String addContactSubmit(@RequestParam String name,
                                   @RequestParam String email,
                                   @RequestParam(required = false) String phone) {
        long newId = idGenerator.getAndIncrement();
        contacts.put(newId, new Contact(newId, name, email, phone != null ? phone : ""));
        return redirectToContacts();
    }

    // Display edit contact form
    @GetMapping("/edit")
    public String editContact(@RequestParam Long id) {
        Contact c = contacts.get(id);
        if (c == null) {
            return "<html><body><h1>Contact not found</h1><a href=\"/contact\">Back to Contacts</a></body></html>";
        }
        StringBuilder html = new StringBuilder();
        html.append(htmlHeader("Edit Contact"));
        html.append("<h1>Edit Contact</h1>");
        html.append("<form method=\"post\" action=\"/contact/edit\">");
        html.append("<input type=\"hidden\" name=\"id\" value=\"" + c.id + "\" />");

        html.append("<label for=\"name\">Full Name</label>");
        html.append("<input type=\"text\" id=\"name\" name=\"name\" required value=\"" + c.name + "\" />");

        html.append("<label for=\"email\">Email</label>");
        html.append("<input type=\"email\" id=\"email\" name=\"email\" required value=\"" + c.email + "\" />");

        html.append("<label for=\"phone\">Phone</label>");
        html.append("<input type=\"tel\" id=\"phone\" name=\"phone\" value=\"" + c.phone + "\" />");

        html.append("<button type=\"submit\" class=\"submit-btn\"><span class=\"material-icons\">edit</span>Save Changes</button>");
        html.append("</form>");
        html.append("<a href=\"/contact\" class=\"back-link\">&larr; Back to Contacts</a>");
        html.append(htmlFooter());
        return html.toString();
    }

    // Handle edit contact form submission
    @PostMapping("/edit")
    public String editContactSubmit(@RequestParam Long id,
                                    @RequestParam String name,
                                    @RequestParam String email,
                                    @RequestParam(required = false) String phone) {
        Contact c = contacts.get(id);
        if (c != null) {
            c.name = name;
            c.email = email;
            c.phone = phone != null ? phone : "";
        }
        return redirectToContacts();
    }

    // Helper redirect to contacts page
    private String redirectToContacts() {
        return "<!DOCTYPE html>" +
                "<html><head>" +
                "<meta http-equiv=\"refresh\" content=\"0; URL=/contact\" />" +
                "</head><body>" +
                "Redirecting to contacts..." +
                "</body></html>";
    }
}

